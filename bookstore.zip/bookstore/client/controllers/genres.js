var myApp = angular.module('myApp');

myApp.controller('GenreController', ['$scope', '$http', '$location', '$routeParams', function($scope, $http, $location, $routeParams){
	console.log('GenreController loaded...');

	$scope.getGenres = function(){
		$http.get('/api/genres').success(function(response){
			$scope.books = response;
		});
	}
	
}]);